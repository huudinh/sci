<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => '6582fe4c96d02e645921e4fb4300f84719b6b503',
        'name' => '__root__',
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => '6582fe4c96d02e645921e4fb4300f84719b6b503',
            'dev_requirement' => false,
        ),
        'asan/phpexcel' => array(
            'pretty_version' => 'v2.0.1',
            'version' => '2.0.1.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../asan/phpexcel',
            'aliases' => array(),
            'reference' => '07ddc15b44c1f3ee967ded35cffeab5fec49a215',
            'dev_requirement' => false,
        ),
    ),
);
