<?php
/**
 * Parser Exception
 *
 * @author Janson
 * @create 2017-11-27
 */
namespace Asan\PHPExcel\Exception;

class ParserException extends \Exception {

}
