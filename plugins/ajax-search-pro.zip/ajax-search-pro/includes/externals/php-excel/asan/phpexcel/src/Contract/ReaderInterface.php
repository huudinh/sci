<?php
/**
 * Reader Interface
 *
 * @author Janson
 * @create 2017-11-23
 */
namespace Asan\PHPExcel\Contract;

interface ReaderInterface extends \SeekableIterator, \Countable {

}
