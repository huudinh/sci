<fieldset
        data-asp_invalid_msg="<?php echo asp_icl_t("Date filter invalid input text" . " ($real_id)", $filter->data['invalid_input_text'], true); ?>"
        class="asp_filter_date<?php echo $filter->data['required'] ? ' asp_required' : ''; ?>">