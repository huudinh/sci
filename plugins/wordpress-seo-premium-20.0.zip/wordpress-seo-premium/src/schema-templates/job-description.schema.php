<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-description" only-nested=true required-for=[ "yoast/job-posting" ] }}
{
	"name": {{html name="description"}}
}
