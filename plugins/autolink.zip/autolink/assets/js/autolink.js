(function($) {
    'use strict';

    $(document).ready(function() {
        $(document).on('click', '.notice-dismiss', function () {
            $(this).parent().remove();
        });

        $('#autolinkAdd').validate({
            rules: {
                keyword: 'required'
            },
            submitHandler: function(form) {
                $.ajax({
                    url: form.action,
                    type: form.method,
                    data: $(form).serialize(),
                    success: function(response) {
                        $('.notice').remove();
                        form.reset();
                        if(response > 0) {
                            $('.wrap > h1').after('<div class="notice notice-success is-dismissible"><p><strong>Success!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        } else {
                            $('.wrap > h1').after('<div class="notice notice-error is-dismissible"><p><strong>Error!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        }
                    },
                    error: function (errorThrown) {
                        console.log(errorThrown);
                    }
                });
            }
        });

        $('#autolinkImport').validate({
            rules: {
                import: {
                    required: true,
                    extension: 'xlsx|xls|xlsm'
                }
            },
            submitHandler: function(form) {
                $.ajax({
                    url: form.action,
                    type: form.method,
                    enctype: 'multipart/form-data',
                    data: new FormData(form),
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        $('.notice').remove();
                        form.reset();
                        if(response > 0) {
                            $('.wrap > h1').after('<div class="notice notice-success is-dismissible"><p><strong>Success!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        } else {
                            $('.wrap > h1').after('<div class="notice notice-error is-dismissible"><p><strong>Error!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        }
                    },
                    error: function (errorThrown) {
                        console.log(errorThrown);
                    }
                });
            }
        });

        $('#autolinkEdit').validate({
            rules: {
                url: 'required'
            },
            submitHandler: function(form) {
                $.ajax({
                    url: form.action,
                    type: form.method,
                    data: $(form).serialize(),
                    success: function(response) {
                        $('.notice').remove();
                        form.reset();
                        if(response > 0) {
                            $('.wrap > h1').after('<div class="notice notice-success is-dismissible"><p><strong>Success!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        } else {
                            $('.wrap > h1').after('<div class="notice notice-error is-dismissible"><p><strong>Error!</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
                        }
                        $('#popupLink').removeClass('active');
                        location.reload();
                    },
                    error: function (errorThrown) {
                        console.log(errorThrown);
                    }
                });
            }
        });
    });
})(jQuery);