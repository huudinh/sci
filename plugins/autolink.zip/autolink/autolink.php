<?php
/**
 * Plugin Name: AutoLink
 * Plugin URI: https://google.com/
 * Description:  link auto
 * Version: 1.0
 * Author: admin
 * Author URI: https://google.com/
 * License: GPLv9
 */

if(!defined('ABSPATH')) exit;

define('AUTOLINK_PATH', plugin_dir_path(__FILE__));
define('AUTOLINK_URL', plugin_dir_url(__FILE__));
define('AUTOLINK_BASE', plugin_basename(__FILE__));

require_once('class.autolink.php');

add_action('init', array('AutoLink', 'init'));