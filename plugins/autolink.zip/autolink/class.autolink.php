<?php
class AutoLink {
    public static function init() {
        self::init_hooks();
    }

    private static function init_hooks() {
        add_action('admin_init', array('AutoLink', 'autolink_db'));
        add_action('admin_init', array('AutoLink', 'manage_autolink_caps'));
        add_action('admin_menu', array('AutoLink', 'autolink_menu_page'));
        add_action('admin_enqueue_scripts', array('AutoLink', 'autolink_enqueue_scripts'));
        add_action('wp_ajax_autolinkAdd', array('AutoLink', 'autolink_add_keyword'));
        add_action('wp_ajax_autolinkAction', array('AutoLink', 'autolink_action'));
        add_action('wp_ajax_autolinkImport', array('AutoLink', 'autolink_import'));
        add_action('wp_ajax_autolinkEdit', array('AutoLink', 'autolink_edit'));
        add_action('admin_notices', array('AutoLink', 'autolink_admin_notice'));
        add_filter('the_content', array('AutoLink', 'autolink_the_content'));
    }

    public static function autolink_db() {
        global $wpdb;
        $table = $wpdb->prefix . 'autolink';
        $charset_collate = $wpdb->get_charset_collate();

        if($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = 'CREATE TABLE '. $table .'(
                ID bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                keyword varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT \'\',
                url varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT \'\',
                priority int(11) NOT NULL DEFAULT 0,
                status int(11) NOT NULL DEFAULT 1,
                PRIMARY KEY (ID)
            )'. $charset_collate;

            require_once(ABSPATH .'wp-admin/includes/upgrade.php');
            dbDelta($sql);
            add_option('autolink_version', '1.0');
        }
    }

    public static function autolink_menu_page() {
        add_menu_page('AutoLink', 'AutoLink', 'manage_autolink', 'autolink', array('AutoLink', 'autolink_settings'), 'dashicons-admin-links');
        add_submenu_page('autolink', 'Add Link', 'Add Link', 'manage_autolink', 'keywords', array('AutoLink', 'autolink_keywords_settings'), 5);
        add_submenu_page('autolink', 'Settings', 'Settings', 'manage_autolink', 'options', array('AutoLink', 'autolink_option_settings'), 10);
    }

    public static function manage_autolink_caps() {
        $role = get_role('administrator');
        $role->add_cap('manage_autolink');
    }

    public static function autolink_settings() {
        ?>
        <div class="wrap autolink">
            <h1>AutoLink</h1>
            <div class="autolink-wrap">
                <div class="autolink-manage">
                    <div id="autolinkAction" class="autolink-action">
                        <select class="autolink-select" name="actions">
                            <option value="">Bulk actions</option>
                            <option value="active">Active</option>
                            <option value="deactive">Deactivate</option>
                            <option value="delete">Delete permanently</option>
                        </select>
                        <button type="submit" class="button button-primary autolink-button">Apply</button>
                    </div>
                    <form id="autolinkFilter" class="autolink-filter" method="GET">
                        <input name="page" value="autolink" type="hidden" />
                        <input name="s" class="autolink-input" type="text" value="<?php echo isset($_GET['s']) ? $_GET['s'] : ''; ?>" placeholder="Enter search keyword or URL" />
                        <button type="submit" class="button button-primary autolink-button">Search</button>
                    </form>
                </div>
                <table class="autolink-table wp-list-table widefat fixed striped table-view-list">
                    <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input id="checkAll" type="checkbox" />
                        </td>
                        <th class="manage-column column-keyword">Keyword</th>
                        <th class="manage-column column-url">URL</th>
                        <th class="manage-column column-author column-priority">Priority</th>
                        <th class="manage-column column-author column-status">Status</th>
                        <th class="manage-column column-author column-action"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php self::autolink_data(); ?>
                    </tbody>
                </table>
                <?php self::autolink_pagination(); ?>
            </div>

            <div id="popupLink" class="popup-link">
                <form id="autolinkEdit" class="autolink-edit" action="<?php echo admin_url('admin-ajax.php?action=autolinkEdit'); ?>" method="POST">
                    <input name="id" type="hidden" value="" />
                    <table class="form-table">
                        <tbody>
                            <tr>
                                <th>URL</th>
                                <td>
                                    <input name="url" class="autolink-input" type="text" value="" />
                                </td>
                            </tr>
                            <tr>
                                <th>Priority</th>
                                <td>
                                    <input name="priority" class="autolink-input" type="number" value="" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="submit">
                        <button type="submit" class="button button-primary autolink-button">Save</button>
                        <button type="button" class="button autolink-button-cancel">Cancel</button>
                    </div>
                </form>
            </div>

            <script>
                (function($) {
                    'use strict';

                    $(document).ready(function() {
                        $(document).on('click', '.autolink-action .autolink-button', function () {
                            var actions = $('.autolink-action .autolink-select option:selected').val(),
                                ids = $('input[name="autolink_id"]').serialize();

                            $.ajax({
                                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                                type: 'POST',
                                dataType: 'JSON',
                                data: {
                                    action: 'autolinkAction',
                                    actions: actions,
                                    ids: ids
                                },
                                success: function(response) {
                                    $('.autolink-action .autolink-select').val('');
                                    $('#checkAll, input[name="autolink_id"]').prop('checked', false);
                                    location.reload();
                                },
                                error: function (errorThrown) {
                                    console.log(errorThrown);
                                }
                            });
                        });

                        $(document).on('click', '.btn-action-edit', function () {
                            var id = $(this).attr('data-id');
                            $('#popupLink input[name="id"]').val(id);
                            $('#popupLink input[name="url"]').val($('.column-url-' + id).html());
                            $('#popupLink input[name="priority"]').val($('.column-priority-' + id).html());
                            $('#popupLink').toggleClass('active');
                        });

                        $(document).on('click', '.autolink-button-cancel', function () {
                            $('#popupLink').toggleClass('active');
                        });
                    });
                })(jQuery);
            </script>
        </div>
        <?php
    }

    public static function autolink_keywords_settings() {
        ?>
        <div class="wrap autolink">
            <h1>Add Link</h1>
            <div class="autolink-wrap autolink-keywords">
                <div class="autolink-add">
                    <div class="autolink-title">Add</div>
                    <div class="autolink-body">
                        <form id="autolinkAdd" class="autolink-form" action="<?php echo admin_url('admin-ajax.php?action=autolinkAdd'); ?>" method="POST">
                            <div class="autolink-container">
                                <label>Keyword</label>
                                <textarea name="keyword" class="autolink-input"></textarea>
                                <p class="description">Here you can enter manually the extra keywords you want to automaticaly link. Use comma to seperate keywords and add target url at the end. Use a new line for new url and set of keywords. You can have these keywords link to any url, not only your site.<br/>Example: Keyword,Url,Priority</p>
                            </div>
                            <div class="submit"><button type="submit" class="button button-primary autolink-button">Add</button></div>
                        </form>
                    </div>
                </div>
                <div class="autolink-import">
                    <div class="autolink-title">Import</div>
                    <div class="autolink-body">
                        <form id="autolinkImport" class="autolink-form" action="<?php echo admin_url('admin-ajax.php?action=autolinkImport'); ?>" method="POST" enctype="multipart/form-data">
                            <table class="form-table">
                                <tbody>
                                <tr>
                                    <th>File</th>
                                    <td>
                                        <input name="import" class="autolink-input" type="file" />
                                        <p class="description">Input file .xlsx, .xls, .xlsm</p>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="submit"><button type="submit" class="button button-primary autolink-button">Import</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function autolink_option_settings() {
        if(!empty($_POST)) {
            $links_type = isset($_POST['links_type']) ? $_POST['links_type'] : '';
            update_option('autolinks_type', $links_type);

            $links_self = isset($_POST['links_self']) ? $_POST['links_self'] : 0;
            update_option('autolinks_self', $links_self);

            $links_max = isset($_POST['links_max']) ? $_POST['links_max'] : 1;
            update_option('autolinks_max', $links_max);

            $links_use = isset($_POST['links_use']) ? $_POST['links_use'] : 1;
            update_option('autolinks_use', $links_use);

            $links_nofollow = isset($_POST['links_nofollow']) ? $_POST['links_nofollow'] : 0;
            update_option('autolinks_nofollow', $links_nofollow);

            $links_blank = isset($_POST['links_blank']) ? $_POST['links_blank'] : 0;
            update_option('autolinks_blank', $links_blank);
        }
        ?>
        <div class="wrap autolink">
            <h1>AutoLink Settings</h1>
            <div class="autolink-wrap autolink-options">
                <form id="autolinkOptions" class="autolink-form" method="POST" novalidate="novalidate">
                    <h3>Target</h3>
                    <?php
                    $post_types = get_post_types(array(
                        'public' => true
                    ));
                    if($post_types) {
                        ?>
                        <p>Can process your posts, pages in search for keywords to automatically interlink.</p>
                        <p>
                            <?php
                            $links_type = get_option('autolinks_type') ? get_option('autolinks_type') : array();
                            foreach ($post_types as $post_type) {
                                $exclude = array('attachment');
                                if(in_array($post_type, $exclude))
                                    continue;
                                ?>
                                <label class="autolink-label" for="links_type_<?php echo $post_type; ?>"><input name="links_type[]" type="checkbox" id="links_type_<?php echo $post_type; ?>" value="<?php echo $post_type; ?>" <?php echo in_array($post_type, $links_type) ? 'checked' : ''; ?> /><?php echo $post_type; ?></label>
                            <?php } ?>
                        </p>
                    <?php } ?>
                    <p>Allow links to self?</p>
                    <p><label class="autolink-label" for="links_self"><input name="links_self" type="checkbox" id="links_self" value="1" <?php checked(get_option('autolinks_self'), 1); ?> />Allow links to self</label></p>
                    <h3>Limits</h3>
                    <p>You can limit the maximum number of different links AutoLink will generate per post. Default is 5. Max links: <input type="number" step="1" min="1" name="links_max" size="2" value="<?php echo get_option('autolinks_max') ? get_option('autolinks_max') : 5; ?>" /></p>
                    <p>Link keyword that have been used at least <input type="number" step="1" min="1" name="links_use" size="2" value="<?php echo get_option('autolinks_use') ? get_option('autolinks_use') : 1; ?>" /> times.</p>
                    <h3>External Links</h3>
                    <p>AutoLink can open external links in new window and add nofollow attribute.</p>
                    <p>
                        <label class="autolink-label" for="links_nofollow"><input name="links_nofollow" type="checkbox" id="links_nofollow" value="1" <?php checked(get_option('autolinks_nofollow'), 1); ?> />Add nofollow attribute</label>
                        <label class="autolink-label" for="links_blank"><input name="links_blank" type="checkbox" id="links_blank" value="1" <?php checked(get_option('autolinks_blank'), 1); ?> />Open in new window</label>
                    </p>
                    <div class="submit"><button type="submit" name="submit" class="button button-primary autolink-button">Save Changes</button></div>
                </form>
            </div>
        </div>
        <?php
    }

    public static function autolink_data($items_per_page = 30) {
        global $wpdb;
        $response = '<tr><td colspan="5" align="center">No data exists!</td></tr>';

        $paged = 1;
        if(isset($_GET['paged']) && $_GET['paged'] > 1)
            $paged = $_GET['paged'];

        $query = $wpdb->get_results('SELECT * FROM '. $wpdb->prefix .'autolink '. (isset($_GET['s']) ? 'WHERE keyword LIKE \'%'. $_GET['s'] .'%\' ' : '') .' ORDER BY ID DESC LIMIT '. $items_per_page .' OFFSET '. ($paged - 1)*$items_per_page);
        if(!empty($query)) {
            $response = '';
            foreach ($query as $item) {
                $response .= '<tr>
                <th class="check-column"><input id="autolink-'. $item->ID .'" name="autolink_id" type="checkbox" value="'. $item->ID .'" /></th>
                <td class="column-keyword column-keyword-'. $item->ID .'">'. $item->keyword .'</td>
                <td class="column-url column-url-'. $item->ID .'">'. $item->url .'</td>
                <td class="column-priority column-priority-'. $item->ID .'">'. $item->priority .'</td>
                <td class="column-status">'. ($item->status == 0 ? 'Deactivate' : 'Active') .'</td>
                <td class="column-action"><button type="button" class="btn-action-edit" data-id="'. $item->ID .'"><i class="icofont-ui-edit"></i></button></td>
            </tr>';
            }
        }

        echo $response;
    }

    public static function autolink_pagination($pages = 1, $range = 3, $items_per_page = 30) {
        global $wpdb;
        $query = $wpdb->get_var('SELECT count(*) FROM '. $wpdb->prefix .'autolink'. (isset($_GET['s']) ? ' WHERE keyword LIKE \'%'. $_GET['s'] .'%\'' : ''));
        if($query > 0) {
            $page_count = (int)ceil($query / $items_per_page);
            if($pages < $page_count) {
                $pages = $page_count;
                $showitems = ($range * 2) + 1;

                $paged = 1;
                if(isset($_GET['paged']))
                    $paged = $_GET['paged'];

                if (1 != $pages) {
                    echo "<div class=\"pagination-wrap\">";
                    if ($paged > 2 && $paged > $range + 1 && $showitems < $pages) echo "<a href='" . get_pagenum_link(1) . "'>«</a>";
                    if ($paged > 1 && $showitems < $pages) echo "<a href='" . get_pagenum_link($paged - 1) . "'>‹</a>";

                    for ($i = 1; $i <= $pages; $i++) {
                        if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
                            echo ($paged == $i) ? "<span class=\"current\">" . $i . "</span>" : "<a href='" . get_pagenum_link($i) . "' class=\"inactive\">" . $i . "</a>";
                        }
                    }

                    if ($paged < $pages && $showitems < $pages) echo "<a href=\"" . get_pagenum_link($paged + 1) . "\">›</i></a>";
                    if ($paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages) echo "<a href='" . get_pagenum_link($pages) . "'>»</a>";
                    echo "</div>\n";
                }
            }
        }
    }

    public static function autolink_add_keyword() {
        $response = 0;
        global $wpdb;

        if(!empty($_POST)) {
            $keyword = isset($_POST['keyword']) ? $_POST['keyword'] : $_POST['keyword'];
            if($keyword) {
                $keywords = explode(PHP_EOL, $keyword);
                foreach ($keywords as $keyword) {
                    $keyword = explode(',', $keyword);

                    $query = 'SELECT * FROM '. $wpdb->prefix .'autolink WHERE keyword = \''. trim($keyword[0]) .'\'';
                    $results = $wpdb->get_row($wpdb->prepare($query));

                    if(empty($results)) {
                        if(!empty($keyword[0]) && !empty($keyword[1])) {
                            if($wpdb->insert(
                                $wpdb->prefix . 'autolink',
                                array(
                                    'keyword' => trim($keyword[0]),
                                    'url' => trim($keyword[1]),
                                    'priority' => !empty($keyword[2]) && $keyword[2] >= 0 ? $keyword[2] : 20000
                                ),
                                array(
                                    '%s',
                                    '%s',
                                    '%d'
                                )
                            )) {
                                $response = $wpdb->insert_id;
                            }
                        }
                    } else {
                        $url = !empty($keyword[1]) ? trim($keyword[1]) : '';
                        $priority = !empty($keyword[2]) && $keyword[2] >= 0 ? $keyword[2] : 20000;

                        if($url && ($results->url != $url || $results->priority != $priority)) {
                            if($wpdb->update(
                                $wpdb->prefix . 'autolink',
                                array(
                                    'url' => $url,
                                    'priority' => $priority
                                ),
                                array('ID' => $results->ID),
                                array(
                                    '%s',
                                    '%d'
                                ),
                                array('%d')
                            )) {
                                $response = (int)$results->ID;
                            }
                        }
                    }
                }
            }
        }

        echo json_encode($response);
        wp_die();
    }

    public static function autolink_action() {
        $response = 0;
        global $wpdb;

        if(!empty($_POST)) {
            $actions = isset($_POST['actions']) ? $_POST['actions'] : '';
            $ids = isset($_POST['ids']) ? $_POST['ids'] : '';

            if(!empty($ids)) {
                $ids = explode(',', str_replace(array('autolink_id=', '&'), array('', ','), $ids));

                switch ($actions) {
                    case 'active':
                        foreach ($ids as $id) {
                            $wpdb->update(
                                $wpdb->prefix . 'autolink',
                                array('status' => 1),
                                array('id' => $id),
                                array('%d'),
                                array('%d')
                            );
                        }
                        break;
                    case 'deactive':
                        foreach ($ids as $id) {
                            $wpdb->update(
                                $wpdb->prefix . 'autolink',
                                array('status' => 0),
                                array('id' => $id),
                                array('%d'),
                                array('%d')
                            );
                        }
                        break;
                    case 'delete':
                        foreach ($ids as $id) {
                            $wpdb->delete(
                                $wpdb->prefix . 'autolink',
                                array('id' => $id)
                            );
                        }
                        break;
                }
            }
        }

        echo json_encode($response);
        wp_die();
    }

    public static function autolink_import() {
        $response = 0;
        global $wpdb;

        if(isset($_FILES['import'])) {
            if(isset($_FILES['import']['name'])) {
                if(isset($_FILES['import']['tmp_name'])) {
                    require_once(AUTOLINK_PATH .'inc/excel/PHPExcel.php');
                    $file = $_FILES['import']['tmp_name'];

                    try {
                        $objFile = PHPExcel_IOFactory::identify($file);
                        $objData = PHPExcel_IOFactory::createReader($objFile);
                        $objData->setReadDataOnly(true);
                        $objPHPExcel = $objData->load($file);
                    } catch(Exception $e) {
                        die('Error loading file: '.$e->getMessage());
                    }
                }
            }

            $data = array();
            $sheet = $objPHPExcel->setActiveSheetIndex(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
            $totalColumn = PHPExcel_Cell::columnIndexFromString($highestColumn);

            for ($i = 2; $i <= $highestRow; $i++) {
                for ($j = 0; $j < $totalColumn; $j++) {
                    if($valueColumn = $sheet->getCellByColumnAndRow($j, $i)->getValue())
                        $data[$i - 2][$j] = $valueColumn;
                }
            }

            if(!empty($data)) {
                foreach ($data as $item) {
                    $query = 'SELECT * FROM '. $wpdb->prefix .'autolink WHERE keyword = \''. trim($item[0]) .'\'';
                    $results = $wpdb->get_row($wpdb->prepare($query));

                    if(empty($results)) {
                        if(!empty($item[0]) && !empty($item[1])) {
                            if($wpdb->insert(
                                $wpdb->prefix . 'autolink',
                                array(
                                    'keyword' => trim($item[0]),
                                    'url' => trim($item[1]),
                                    'priority' => !empty($item[2]) && $item[2] >= 0 ? $item[2] : 20000
                                ),
                                array(
                                    '%s',
                                    '%s',
                                    '%d'
                                )
                            )) {
                                $response = $wpdb->insert_id;
                            }
                        }
                    } else {
                        $url = !empty($item[1]) ? trim($item[1]) : '';
                        $priority = !empty($item[2]) && $item[2] >= 0 ? $item[2] : 20000;

                        if($url && ($results->url != $url || $results->priority != $priority)) {
                            if($wpdb->update(
                                $wpdb->prefix . 'autolink',
                                array(
                                    'url' => $url,
                                    'priority' => $priority
                                ),
                                array('ID' => $results->ID),
                                array(
                                    '%s',
                                    '%d'
                                ),
                                array('%d')
                            )) {
                                $response = (int)$results->ID;
                            }
                        }
                    }
                }
            }
        }

        echo json_encode($response);
        wp_die();
    }

    public static function autolink_edit() {
        $response = 0;
        global $wpdb;

        if(!empty($_POST)) {
            $id = isset($_POST['id']) ? $_POST['id'] : $_POST['id'];
            $url = isset($_POST['url']) ? $_POST['url'] : $_POST['url'];
            $priority = isset($_POST['priority']) ? $_POST['priority'] : 20000;
            if($id && $url) {
                if($wpdb->update(
                    $wpdb->prefix . 'autolink',
                    array(
                        'url' => $url,
                        'priority' => $priority
                    ),
                    array('ID' => $id),
                    array(
                        '%s',
                        '%d'
                    ),
                    array('%d')
                )) {
                    $response = (int)$id;
                }
            }
        }

        echo json_encode($response);
        wp_die();
    }

    public static function autolink_admin_notice() {
        $screen = get_current_screen();
        if($screen->base == 'autolink_page_options') {
            if(!empty($_POST)) {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php _e('Plugin settings saved.', 'autolink'); ?></p>
                </div>
                <?php
            }
        }
    }

    public static function autolink_the_content($content) {
        if(!is_admin() && (is_single() || is_page())) {
            global $wpdb, $wp, $post;
            $links_type = get_option('autolinks_type') ? get_option('autolinks_type') : array();

            if(in_array($post->post_type, $links_type)) {
                $pattern_link = '#<a.*?>(.*?)</a>#i';
                $content = preg_replace($pattern_link, '\1', $content);
                $options = self::autolink_get_options();

                $items = wp_cache_get('autolink', 'autolinks');
                if(empty($items)) {
                    $query = $wpdb->get_results('SELECT * FROM '. $wpdb->prefix .'autolink WHERE status=1 ORDER BY priority DESC, LENGTH(keyword) DESC');
                    $items = $query;
                    wp_cache_add('autolink', $query, 'autolinks', 86400);
                }

                $content = preg_split('/\r\n|\r|\n/', $content);

                $countKeyword = 1;
                foreach ($items as $item) {
                    $url = $item->url;
                    $parse_url = parse_url($url);

                    if($options->self == 0 && $parse_url['path'] == '/'. $wp->request)
                        continue;

                    $name = preg_quote($item->keyword, '/');
                    $pattern_keyword = '/(?<!\pL)($name)(?!\pL)(?!(?:(?!<\/?[ha].*?>).)*<\/[ha].*?>)(?![^<>]*>)/iumU';
                    $replace = '<a title="$1" href="'. $url .'"'. $options->nofollow . $options->blank .'>$1</a>';
                    $regexp = str_replace('$name', $name, $pattern_keyword);

                    foreach ($content as $k => $paragraph) {
                        if(preg_match($pattern_link, $paragraph) || !preg_match($regexp, $paragraph))
                            continue;

                        $content[$k] = preg_replace($regexp, $replace, $paragraph, $options->times);
                        $countKeyword++;
                        break;
                    }

                    if($countKeyword >= $options->links_max)
                        break;
                }
            }
        }

        if(is_array($content))
            return implode('', $content);

        return $content;
    }

    public static function autolink_get_options() {
        $options = array();
        $options['self'] = get_option('autolinks_self');
        $options['nofollow'] = get_option('autolinks_nofollow') == 1 ? ' rel="nofollow"' : '';
        $options['blank'] = get_option('autolinks_blank') == 1 ? ' target="_blank"' : '';
        $options['links_max'] = get_option('autolinks_max') > 0 ? get_option('autolinks_max') : 5;
        $options['times'] = get_option('autolinks_use') ? get_option('autolinks_use') : 1;

        return (object)$options;
    }

    public static function autolink_enqueue_scripts() {
        $screen = get_current_screen();
        $base = array('toplevel_page_autolink', 'autolink_page_keywords', 'autolink_page_options');

        if(in_array($screen->base, $base)) {
            if(!did_action('wp_enqueue_media'))
                wp_enqueue_media();

            wp_enqueue_script('validation', AUTOLINK_URL . 'assets/js/validation/jquery.validate.min.js', array('jquery'));
            wp_enqueue_script('validation-methods', AUTOLINK_URL . 'assets/js/validation/additional-methods.min.js', array('jquery'));
            wp_enqueue_script('autolink', AUTOLINK_URL . 'assets/js/autolink.js', array('jquery'));
            wp_enqueue_style('icofont', AUTOLINK_URL . 'assets/lib/icofont/icofont.min.css');
            wp_enqueue_style('autolink', AUTOLINK_URL . 'assets/css/autolink.css');
        }
    }
}