<?php
    //API Key - see http://admin.mailchimp.com/account/api
    $apikey = '31976edb0d1066de125d6f51393f25aa-us6';
    
    // A List Id to run examples against. use lists() to view all
    // Also, login to MC account, go to List, then List Tools, and look for the List ID entry
    $listId = '1b516804a2';
    
    //just used in xml-rpc examples
    $apiUrl = 'http://api.mailchimp.com/1.3/';
    
?>
