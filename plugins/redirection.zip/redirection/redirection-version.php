<?php

define( 'REDIRECTION_VERSION', '5.3.2' );
define( 'REDIRECTION_BUILD', 'c785eb862c23d732cc3689b27f4eec09' );
define( 'REDIRECTION_MIN_WP', '5.4' );
