<?php
/**
 * Plugin Name: SCI CHECK SEO
 * Plugin URI: #
 * Description: SCI CHECK SEO
 * Version: 1.0
 * Author: SCI CHECK SEO
 * Author URI: #
 * License: GPLv2
 */

if( !defined( 'ABSPATH' ) ) exit;

define( 'sci_checker', plugin_dir_path( __FILE__ ) );
define( 'sci_checker_URL', plugin_dir_url( __FILE__ ) );

require_once( sci_checker . 'includes/class-seo-analyzer-options.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-helper.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-functions.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-frontend.php' );