<?php
/**
 * Plugin Name: SCI CHECK NỘI DUNG BÀI VIẾT
 * Plugin URI: #
 * Description: SCI CHECK NỘI DUNG BÀI VIẾT
 * Version: 2.6
 * Author: SCI CHECK NỘI DUNG BÀI VIẾT
 * Author URI: #
 * License: GPLv2
 */

if( !defined( 'ABSPATH' ) ) exit;

define( 'sci_checker', plugin_dir_path( __FILE__ ) );
define( 'sci_checker_URL', plugin_dir_url( __FILE__ ) );

require_once( sci_checker . 'includes/class-seo-analyzer-options.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-helper.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-functions.php' );
require_once( sci_checker . 'includes/class-seo-analyzer-frontend.php' );