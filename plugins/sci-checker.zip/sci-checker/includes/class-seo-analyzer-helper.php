<?php
function sci_checker_str_length( $str ) {
    $count = 0;
    $str = strip_tags($str);

    if(stripos($str, ' ')){
        $ex_str = explode(' ', $str);
        $count = count($ex_str);
    }

    return $count;
}

function sci_checker_response_data( $tag, $cls, $message ) {
    $response = '<'. $tag .' class="'. $cls .'">'. $message .'</'. $tag .'>';
    return $response;
}

function sci_checker_is_str( $str, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    if(!empty($str))
        $cls = 'sa-success';

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_length_str( $str, $message, $word, $characters, $type = 0, $tag = 'li' ) {
    $cls = 'sa-error';

    if($type === 0) {
        if(!empty($str) && !empty($word) && empty($characters) && sci_checker_str_length($str) <= $word) {
            $cls = 'sa-success';
        } elseif(!empty($str) && empty($word) && !empty($characters) && mb_strlen($str, 'UTF-8') <= $characters) {
            $cls = 'sa-success';
        } elseif(!empty($str) && !empty($word) && !empty($characters) && sci_checker_str_length($str) <= $word && mb_strlen($str, 'UTF-8') <= $characters) {
            $cls = 'sa-success';
        }
    } elseif($type === 1)  {
        if(!empty($str) && !empty($word) && sci_checker_str_length($str) >= $word) {
            $cls = 'sa-success';
        }
    }

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_str( $keyword, $str, $message, $tag = 'li' ) {
    $cls = 'sa-error';
    $check = false;

    if(!empty($str) && !empty($keyword)) {
        if(stripos($keyword, ' ')){
            $ex_keyword = explode(' ', $keyword);

            foreach ($ex_keyword as $item_keyword) {
                if(stripos(mb_strtolower($str, 'UTF-8'), mb_strtolower($item_keyword, 'UTF-8')) !== false) {
                    $check = true;
                } else {
                    $check = false;
                    break;
                }
            }
        }
    }

    if($check) {
        $cls = 'sa-success';
    }

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_is_tags( $tags, $str, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName($tags)->length > 0)
        $cls = 'sa-success';

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_is_sapo($sapo, $message, $tag = 'li') {
    $cls = 'sa-error';

    if(!empty($sapo))
        $cls = 'sa-success';

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_count_tags( $tags, $str, $count, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName($tags)->length >= $count)
        $cls = 'sa-success';

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_tags( $tags, $str, $keyword, $min = 1, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName($tags)->length > 0) {
        $count = 0;

        foreach($domObj->getElementsByTagName($tags) as $node) {
            $check = false;
            $node_value = $node->nodeValue;

            if(!empty($keyword)) {
                $ex_keyword = explode(' ', $keyword);

                foreach ($ex_keyword as $item_keyword) {
                    if(stripos(mb_strtolower($node_value, 'UTF-8'), mb_strtolower($item_keyword, 'UTF-8')) !== false) {
                        $check = true;
                    } else {
                        $check = false;
                        break;
                    }
                }

                if($check) {
                    $count++;
                }
            }
        }

        if($count >= $min) {
            $cls = 'sa-success';
        }
    }

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_attr_tags( $tags, $str, $attr, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName($tags)->length > 0) {
        $check = false;

        foreach($domObj->getElementsByTagName($tags) as $node) {
            $node_value = $node->getAttribute('alt');

            if(!empty($node_value)) {
                $check = true;
            } else {
                $check = false;
                break;
            }
        }

        if($check) {
            $cls = 'sa-success';
        }
    }

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_attr_tags( $tags, $str, $attr, $keyword, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName($tags)->length > 0) {
        $check = false;

        foreach($domObj->getElementsByTagName($tags) as $node) {
            $node_value = $node->getAttribute($attr);

            if(!empty($node_value) && !empty($keyword)) {
                if(stripos($keyword, ' ')) {
                    $check_keyword = false;
                    $ex_keyword = explode(' ', $keyword);

                    foreach ($ex_keyword as $item_keyword) {
                        if(stripos(mb_strtolower($node_value, 'UTF-8'), mb_strtolower($item_keyword, 'UTF-8')) !== false) {
                            $check_keyword = true;
                        } else {
                            $check_keyword = false;
                            break;
                        }
                    }

                    if($check_keyword) {
                        $check = true;
                    }
                }
            }
        }

        if($check) {
            $cls = 'sa-success';
        }
    }

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_first_content( $str, $keyword, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    $content = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
    $domObj = new DOMDocument();

    libxml_use_internal_errors(true);
    @$domObj->loadHTML(utf8_decode($content));

    if($domObj->getElementsByTagName('*')->length >= 2) {
        $check = false;
        $node = $domObj->getElementsByTagName('*')->item(2);
        $node_value = $node->nodeValue;

        if(!empty($node_value) && !empty($keyword)) {
            if(stripos(mb_strtolower($node_value, 'UTF-8'), mb_strtolower($keyword, 'UTF-8')) !== false) {
                $check = true;
            } else {
                $check = false;
            }
        }

        if($check) {
            $cls = 'sa-success';
        }
    }

    $content = $domObj->saveHtml();

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_content( $str, $keyword, $min, $max, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    if(!empty($keyword)) {
        $check = false;
        $keyword_count = mb_substr_count(mb_strtolower($str), mb_strtolower($keyword), 'UTF-8');

        if(empty($max) && !empty($min)) {
            $keyword_percent = (($keyword_count*sci_checker_str_length($keyword))/sci_checker_str_length($str))*100;

            if($keyword_percent >= $min) {
                $check = true;
            }
        } elseif(!empty($max) && empty($min)) {
            $keyword_percent = round((($keyword_count*sci_checker_str_length($keyword))/sci_checker_str_length($str))*100, 1);
            if($keyword_percent == NAN){
                $keyword_percent = 0;
            }
            echo '<div style="font-size:16px;font-weight:600">% từ khóa trong bài: '.$keyword_percent.'%';
            echo '<br>% giới hạn từ khóa 2% (lưu ý: không được phép vượt quá) '.$max.'%</div>';
            if($keyword_percent <= $max) {
                $check = true;
            }
        }
        if($check) {
            $cls = 'sa-success';
        }
    }

    echo sci_checker_response_data($tag, $cls, $message);
}

function sci_checker_keyword_in_tags( $tags, $keyword, $message, $tag = 'li' ) {
    $cls = 'sa-error';

    if(!empty($keyword) && count($tags) > 0) {
        $check = false;

        if(in_array(mb_strtolower($keyword), $tags)) {
            $check = true;
        }

        if($check) {
            $cls = 'sa-success';
        }
    }

    echo sci_checker_response_data($tag, $cls, $message);
}