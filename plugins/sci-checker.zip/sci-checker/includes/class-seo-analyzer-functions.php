<?php
function sci_checker_response_title() {
    $title = $_POST['title'];
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];
    ?>
    <div class="sa-response-wrapper sa-title-wrapper">
        <h3>Title / <?php echo mb_strlen($title, 'UTF-8'); ?> ký tự</h3>
        <ul>
            <?php
            sci_checker_is_str($title, 'Đã có tiêu đề bài viết');
            sci_checker_length_str($title, 'Độ dài thẻ tiêu đề giới hạn 70 ký tự', '', 70);
            sci_checker_keyword_str($keyword, $title, 'Từ khóa chính trong tiêu đề');
            sci_checker_keyword_str($subkeyword, $title, 'Từ khóa phụ trong tiêu đề');
            ?>
        </ul>
    </div>
    <?php
}

function sci_checker_response_description() {
    $description = $_POST['description'];
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];
    ?>
    <div class="sa-response-wrapper sa-sapo-wrapper">
        <h3>Description / <?php echo mb_strlen($description, 'UTF-8'); ?> ký tự</h3>
        <ul>
            <?php
            sci_checker_is_str(strip_tags($description), 'Có nội dung trong thẻ mô tả');
            sci_checker_length_str(strip_tags($description), 'Meta description không vượt quá 160 ký tự', '', 160);
            sci_checker_keyword_str($keyword, strip_tags($description), 'Đã có từ khóa chính trong Meta description');
            sci_checker_keyword_str($subkeyword, strip_tags($description), 'Đã có từ khóa phụ trong Meta description');
            ?>
        </ul>
    </div>
    <?php
}

function sci_checker_response_sapo() {
    if(get_option('sci_checker_field_sapo') == 1 && get_option('sci_checker_field_sapo_name')) {
        $sapo = $_POST['sapo'];
        $keyword = $_POST['keyword'];
        $subkeyword = $_POST['subkeyword'];
        ?>
        <div class="sa-response-wrapper sa-description-wrapper">
            <h3>Sapo / <?php echo mb_strlen($sapo, 'UTF-8'); ?> ký tự</h3>
            <ul>
                <?php
                sci_checker_length_str(strip_tags($sapo), 'Sapo Bài viết không vượt quá 160 ký tự', '', 160);
                sci_checker_keyword_str($keyword, strip_tags($sapo), 'Bài viết Đã có từ khóa chính trong nội dung sapo');
                sci_checker_keyword_str($subkeyword, strip_tags($sapo), 'Bài viết Đã có từ khóa phụ trong nội dung sapo');
                ?>
            </ul>
        </div>
        <?php
    }
}

function sci_checker_response_heading() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];

    if(get_option('sci_checker_field_sapo') == 1 && get_option('sci_checker_field_sapo_name')) {
        $sapo = stripslashes($_POST['sapo']);
    }
    ?>
    <div class="sa-response-wrapper sa-heading-wrapper">
        <h3>Heading</h3>
        <ul>
            <?php
            if(get_option('sci_checker_field_sapo') == 1 && get_option('sci_checker_field_sapo_name')) {
                sci_checker_is_sapo($sapo, 'Đã có thẻ H2 trong trang');
            } else {
                sci_checker_is_tags('h2', $content, 'Đã có thẻ H2 trong bài');
            }

            sci_checker_count_tags('h3', $content, 2, 'Cần có ít nhất 2 thẻ H3 trong bài');
            sci_checker_keyword_tags('h3', $content, $keyword, 2, ' Cần có ít nhất 2 thẻ H3 chứa từ khóa chính ');
            ?>
        </ul>
    </div>
    <?php
}

function sci_checker_response_image() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];
    ?>
    <div class="sa-response-wrapper sa-image-wrapper">
        <h3>Image</h3>
        <ul>
            <?php
            sci_checker_count_tags('img', $content, 5, 'Có ít nhất 5 hình ảnh trong bài viết');
            sci_checker_attr_tags('img', $content, 'alt', 'Cần có viết nội dung ALT cho tất cả hình ảnh');
            sci_checker_keyword_attr_tags('img', $content, 'alt', $keyword, 'Cần có từ khóa chính trong nội dung ALT của hình ảnh');
            ?>
        </ul>
    </div>
    <?php
}

function sci_checker_response_content() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];

    if(get_option('sci_checker_field_sapo') == 1 && get_option('sci_checker_field_sapo_name')) {
        $sapo = stripslashes($_POST['sapo']);
    }
    ?>
    <div class="sa-response-wrapper sa-content-wrapper">
        <h3>Content / <?php echo sci_checker_str_length($content) ?> từ</h3>
        <ul>
            <?php
            sci_checker_length_str($content, 'Nội dung đạt độ dài 1500 từ', 1500, '', 1);
            if(get_option('sci_checker_field_sapo') == 1 && get_option('sci_checker_field_sapo_name')) {
                sci_checker_keyword_first_content($sapo, $keyword, 'Từ khóa chính xuất hiện ở đoạn văn bản đầu tiên của bài');
            } else {
                sci_checker_keyword_first_content($content, $keyword, 'Từ khóa chính xuất hiện ở đoạn văn bản đầu tiên của bài');
            }
            sci_checker_keyword_content($content, $keyword, 1, '', 'Từ khóa chính đạt đủ mật độ tối thiểu 1% của nội dung bài');
            sci_checker_keyword_content($content, $keyword, '', 2, 'Từ khóa chính không vượt quá 2% nội dung bài');
            sci_checker_keyword_content($content, $subkeyword, 1, '', 'Từ khóa phụ xuất hiện tối thiểu 1% bên trong nội dung bài');
            ?>
        </ul>
    </div>
    <?php
}

function sci_checker_response_tag() {
    $tags = $_POST['tags'];
    $keyword = $_POST['keyword'];

    $terms_tag = array();
    if(get_option('sci_checker_editor_used') == 0):
        $terms = get_terms(
            array(
                'taxonomy' => 'post_tag',
                'hide_empty' => false,
                'include' => $tags
            )
        );

        foreach ($terms as $term):
            array_push($terms_tag, mb_strtolower(trim($term->name)));
        endforeach;
    else:
        if($tags) {
            $terms = explode(',', $tags);

            foreach ($terms as $term):
                array_push($terms_tag, mb_strtolower(trim($term)));
            endforeach;
        }
    endif;
    ?>
    <div class="sa-response-wrapper sa-tags-wrapper">
        <h3>Tags</h3>
        <ul>
            <?php sci_checker_keyword_in_tags($terms_tag, $keyword, 'Thẻ Tags đã có từ khóa chính'); ?>
        </ul>
    </div>
    <?php
}

add_action('sci_checker_frontend', 'sci_checker_response_title', 5);
add_action('sci_checker_frontend', 'sci_checker_response_description', 10);
add_action('sci_checker_frontend', 'sci_checker_response_sapo', 10);
add_action('sci_checker_frontend', 'sci_checker_response_heading', 15);
add_action('sci_checker_frontend', 'sci_checker_response_image', 20);
add_action('sci_checker_frontend', 'sci_checker_response_content', 25);
add_action('sci_checker_frontend', 'sci_checker_response_tag', 30);

function sci_checker_post_types() {
    $post_types = array(
        'post' => __('Posts'),
        'page' => __('Pages')
    );

    return $post_types;
}