<?php
function sci_checker_scripts() {
    wp_enqueue_style('seo-analyzer-css', sci_checker_URL .'assets/css/styles.css');
}
add_action( 'admin_enqueue_scripts', 'sci_checker_scripts' );

function sci_checker_meta_boxes() {
    $data_post_types = get_option('sci_checker_post_types');

    $post_types = sci_checker_post_types();
    if(is_array( $post_types ) && $post_types !== array() && is_array( $data_post_types ) && $data_post_types !== array()) {
        foreach ($post_types as $k => $post_type) {
            if(!empty($data_post_types[$k]) && $data_post_types[$k] == 1) {
                add_meta_box( 'seo-analyzer', 'SCI Checker', 'sci_checker_output', $k );
            }
        }
    }
}
add_action( 'add_meta_boxes', 'sci_checker_meta_boxes' );

function sci_checker_output() {
    ?>
    <div class="seo-analyzer">
        <div class="sa-row">
            <div class="sa-col">
                <div class="seo-analyzer-form">
                    <div class="form-group">
                        <label>Từ khóa:</label>
                        <input class="form-control sa-keyword" name="sa-keyword" type="text" placeholder="Nhập từ khóa" />
                    </div>
                    <div class="form-group">
                        <label>Từ khóa phụ:</label>
                        <input class="form-control sa-subkeyword" name="sa-subkeyword" type="text" placeholder="Nhập từ khóa phụ" />
                    </div>
                    <div class="form-group text-center">
                        <button class="btn btn-success seo-analyzer-check" type="button">Kiểm tra</button>
                    </div>
                </div>
            </div>
            <div class="sa-col">
                <div class="seo-analyzer-response"></div>
            </div>
        </div>

        <script>
            (function($) {
                'use strict';
                var title,
                    content,
                    keyword,
                    subkeyword,
                    description,
                    tags,
                    sapo;

                $(document).on('click', '.seo-analyzer-check', function() {
                    <?php
                    $editor_used = get_option('sci_checker_editor_used');
                    if($editor_used == 1):
                    ?>
                        title = $('#title').val();
                        content = $('#content').val();
                        tags = $('[name="tax_input[post_tag]"]').val();
                    <?php elseif($editor_used == 2): ?>
                        title = $('#title').val();
                        content = tinymce.activeEditor.getContent();
                        tags = $('[name="tax_input[post_tag]').val();
                    <?php else: ?>
                        title = wp.data.select('core/editor').getEditedPostAttribute('title');
                        content = wp.data.select('core/editor').getEditedPostAttribute('content');
                        tags = wp.data.select('core/editor').getEditedPostAttribute('tags');
                    <?php endif; ?>

                    keyword = $('.seo-analyzer .sa-keyword').val();
                    subkeyword = $('.seo-analyzer .sa-subkeyword').val();

                    <?php
                    if(get_option('sci_checker_acf_use') == 1):
                        if(get_option('sci_checker_field_is_acf') == 1 && get_option('sci_checker_acf_field')):
                        ?>
                            var data_acf = acf.findFields({name: '<?php echo get_option('sci_checker_acf_field'); ?>'});
                            description = $('[name="acf[' + data_acf.data().key + ']"]').val();
                        <?php else: ?>
                            description = $('[name="<?php echo get_option('sci_checker_acf_field'); ?>"]').val();
                        <?php
                        endif;
                    else:
                        if($editor_used == 1 || $editor_used == 2):
                            ?>
                            description = $('#excerpt').val();
                        <?php else: ?>
                            description = wp.data.select('core/editor').getEditedPostAttribute('excerpt');
                        <?php
                        endif;
                    endif;
                    ?>

                    <?php
                    if(get_option('sci_checker_field_sapo') == 1):
                        if(get_option('sci_checker_sapo_is_acf') == 1 && get_option('sci_checker_field_sapo_name')):
                        ?>
                            var data_sapo = acf.findFields({name: '<?php echo get_option('sci_checker_field_sapo_name'); ?>'});
                            sapo = $('[name="acf[' + data_sapo.data().key + ']"]').val();
                        <?php else: ?>
                            sapo = $('[name="<?php echo get_option('sci_checker_field_sapo_name'); ?>"]').val();
                            <?php
                        endif;
                    endif;
                    ?>

                    $.ajax({
                        type : 'POST',
                        dataType : 'JSON',
                        url : '<?php echo admin_url('admin-ajax.php'); ?>',
                        data : {
                            action : 'seoAnalyzer',
                            title : title,
                            content : content,
                            description : description,
                            keyword : keyword,
                            subkeyword : subkeyword,
                            tags : tags,
                            sapo: sapo
                        },
                        beforeSend: function() {
                            $('.lds-overlay').fadeIn();
                        },
                        success: function(response) {
                            $('.seo-analyzer-response').html(response);
                            $('.lds-overlay').fadeOut();
                        },
                        error: function (errorThrown) {
                            console.log(errorThrown);
                        }
                    });
                });
            })(jQuery);
        </script>

        <div class="lds-overlay">
            <div class="lds-loading"><span></span><span></span><span></span></div>
        </div>
    </div>
    <?php
}

function sci_checker_add_submenu_options() {
    add_submenu_page(
        'options-general.php',
        'SCI Checker',
        'SCI Checker',
        'manage_options',
        'sci-checker',
        'sci_checker_access_menu_options'
    );
}
add_action('admin_menu', 'sci_checker_add_submenu_options');

function sci_checker_access_menu_options() {
    if (!empty($_POST['submit'])) {

        $editor_used = isset($_POST['editor_used']) ? $_POST['editor_used'] : 0;
        update_option('sci_checker_editor_used', $editor_used);

        $post_types = isset($_POST['post_types']) ? $_POST['post_types'] : '';
        update_option('sci_checker_post_types', $post_types);

        $acf_use = isset($_POST['acf_use']) ? $_POST['acf_use'] : 0;
        update_option('sci_checker_acf_use', $acf_use);

        $acf_field = isset($_POST['acf_field']) ? $_POST['acf_field'] : '';
        update_option('sci_checker_acf_field', $acf_field);

        $field_is_acf = isset($_POST['field_is_acf']) ? $_POST['field_is_acf'] : 0;
        update_option('sci_checker_field_is_acf', $field_is_acf);

        $field_sapo = isset($_POST['field_sapo']) ? $_POST['field_sapo'] : 0;
        update_option('sci_checker_field_sapo', $field_sapo);

        $field_sapo_name = isset($_POST['field_sapo_name']) ? $_POST['field_sapo_name'] : '';
        update_option('sci_checker_field_sapo_name', $field_sapo_name);

        $sapo_is_acf = isset($_POST['sapo_is_acf']) ? $_POST['sapo_is_acf'] : 0;
        update_option('sci_checker_sapo_is_acf', $sapo_is_acf);
    }

    require_once(sci_checker . 'templates/options.php');
}