<?php
$data_editor_used = get_option('seo_analyzer_editor_used');
$data_post_types = get_option('seo_analyzer_post_types');
$data_acf_use = get_option('seo_analyzer_acf_use');
?>
<div class="wrap sa-wrap">
    <h1>SEO Analyzer Settings</h1>

    <form method="post" action="" novalidate="novalidate">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">Editor Used</th>
                    <td>
                        <p>
                            <select id="editor_used" name="editor_used">
                                <option value="0" <?php selected( $data_editor_used, 0 ); ?>>Gutenberg Editor</option>
                                <option value="1" <?php selected( $data_editor_used, 1 ); ?>>Classic Editor</option>
                                <option value="2" <?php selected( $data_editor_used, 2 ); ?>>TinyMCE Advanced</option>
                            </select>
                        </p>
                    </td>
                </tr>
                <?php
                $post_types = seo_analyzer_post_types();
                if(is_array( $post_types ) && $post_types !== array()):
                    ?>
                    <tr>
                        <th scope="row">Support Post Types</th>
                        <td>
                            <p>
                            <?php foreach ($post_types as $k => $post_type): ?>
                                <label for="post_types_<?php echo $k; ?>"><input id="post_types_<?php echo $k; ?>" name="post_types[<?php echo $k; ?>]" type="checkbox" value="1" <?php if(!empty($data_post_types[$k])) checked( $data_post_types[$k], 1 ); ?>> <?php echo $post_type; ?></label>
                            <?php endforeach; ?>
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th scope="row">Custom Field</th>
                    <td>
                        <p><label for="acf_use"><input id="acf_use" name="acf_use" type="checkbox" value="1" <?php checked( $data_acf_use, 1 ); ?> /> Use Custom Field As Description</label></p>
                    </td>
                </tr>
                <tr class="acf-use" <?php if($data_acf_use != 1) echo 'style="display: none;"' ?>>
                    <th scope="row"></th>
                    <td>
                        <p><input type="text" class="regular-text code" name="acf_field" value="<?php echo get_option('seo_analyzer_acf_field'); ?>" /></p>
                        <p class="description">Input name custom field. Ex: name_custom_field</p>
                        <p><label for="field_is_acf"><input id="field_is_acf" name="field_is_acf" type="checkbox" value="1" <?php checked( get_option('seo_analyzer_field_is_acf'), 1 ); ?> />The custom field is created by the Advanced Custom Fields plugin</label></p>
                    </td>
                </tr>
                <tr class="sa-sapo">
                    <th scope="row"></th>
                    <td>
                        <p><label for="field_sapo"><input id="field_sapo" name="field_sapo" type="checkbox" value="1" <?php checked( get_option('seo_analyzer_field_sapo'), 1 ); ?> />Use Sapo field</label></p>
                        <div class="field-sapo-group" <?php if(get_option('seo_analyzer_field_sapo') != 1) echo 'style="display: none;"' ?>>
                            <p><input type="text" class="regular-text code" name="field_sapo_name" value="<?php echo get_option('seo_analyzer_field_sapo_name'); ?>" /></p>
                            <p class="description">Input name Sapo field. Ex: name_sapo_field</p>
                            <p><label for="field_is_acf"><input id="sapo_is_acf" name="sapo_is_acf" type="checkbox" value="1" <?php checked( get_option('seo_analyzer_sapo_is_acf'), 1 ); ?> />The Sapo field is created by the Advanced Custom Fields plugin</label></p>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes" /></p>
    </form>

    <script>
        (function($) {
            'use strict';

            $(document).ready(function() {
                $('#acf_use').change(function(){
                    if(this.checked) {
                        $('.acf-use').fadeIn('fast');
                    } else {
                        $('.acf-use').fadeOut('fast');
                    }
                });

                $('#field_sapo').change(function(){
                    if(this.checked) {
                        $('.field-sapo-group').fadeIn('fast');
                    } else {
                        $('.field-sapo-group').fadeOut('fast');
                    }
                });
            });
        })(jQuery);
    </script>
</div>
