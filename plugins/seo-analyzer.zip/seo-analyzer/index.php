<?php
/**
 * Plugin Name: CHECK SEO
 * Plugin URI: #
 * Description: CHECK SEO
 * Version: 1.0
 * Author: CHECK SEO
 * Author URI: #
 * License: GPLv2
 */

if( !defined( 'ABSPATH' ) ) exit;

define( 'SEO_ANALYZER', plugin_dir_path( __FILE__ ) );
define( 'SEO_ANALYZER_URL', plugin_dir_url( __FILE__ ) );

require_once( SEO_ANALYZER . 'includes/class-seo-analyzer-options.php' );
require_once( SEO_ANALYZER . 'includes/class-seo-analyzer-helper.php' );
require_once( SEO_ANALYZER . 'includes/class-seo-analyzer-functions.php' );
require_once( SEO_ANALYZER . 'includes/class-seo-analyzer-frontend.php' );