<?php
function seoAnalyzer() {
    if($_POST) {
        ob_start();

        do_action( 'seo_analyzer_frontend' );
        $response = ob_get_contents();

        ob_end_clean();

        echo wp_json_encode($response);
    }

    wp_die();
}
add_action('wp_ajax_seoAnalyzer', 'seoAnalyzer');