<?php
function seo_analyzer_response_title() {
    $title = $_POST['title'];
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];
    ?>
    <div class="sa-response-wrapper sa-title-wrapper">
        <h3>Title / <?php echo mb_strlen($title, 'UTF-8'); ?> ký tự</h3>
        <ul>
            <?php
            seo_analyzer_is_str($title, 'Đã có tiêu đề');
            seo_analyzer_length_str($title, 'Thẻ tiêu đề không vượt quá 70 ký tự', '', 70);
            seo_analyzer_keyword_str($keyword, $title, 'Đã có từ khóa chính trong thẻ tiêu đề');
            seo_analyzer_keyword_str($subkeyword, $title, 'Đã có từ khóa phụ trong thẻ tiêu đề');
            ?>
        </ul>
    </div>
    <?php
}

function seo_analyzer_response_description() {
    $description = $_POST['description'];
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];
    ?>
    <div class="sa-response-wrapper sa-sapo-wrapper">
        <h3>Description / <?php echo mb_strlen($description, 'UTF-8'); ?> ký tự</h3>
        <ul>
            <?php
            seo_analyzer_is_str(strip_tags($description), 'Đã có thẻ mô tả nội dung');
            seo_analyzer_length_str(strip_tags($description), 'Thẻ mô tả nội dung không vượt quá 160 ký tự', '', 160);
            seo_analyzer_keyword_str($keyword, strip_tags($description), 'Đã có từ khóa chính trong thẻ mô tả nội dung');
            seo_analyzer_keyword_str($subkeyword, strip_tags($description), 'Đã có từ khóa phụ trong thẻ mô tả nội dung');
            ?>
        </ul>
    </div>
    <?php
}

function seo_analyzer_response_sapo() {
    if(get_option('seo_analyzer_field_sapo') == 1 && get_option('seo_analyzer_field_sapo_name')) {
        $sapo = $_POST['sapo'];
        $keyword = $_POST['keyword'];
        $subkeyword = $_POST['subkeyword'];
        ?>
        <div class="sa-response-wrapper sa-description-wrapper">
            <h3>Sapo / <?php echo mb_strlen($sapo, 'UTF-8'); ?> ký tự</h3>
            <ul>
                <?php
                seo_analyzer_length_str(strip_tags($sapo), 'Sapo không vượt quá 160 ký tự', '', 160);
                seo_analyzer_keyword_str($keyword, strip_tags($sapo), 'Đã có từ khóa chính trong nội dung sapo');
                seo_analyzer_keyword_str($subkeyword, strip_tags($sapo), 'Đã có từ khóa phụ trong nội dung sapo');
                ?>
            </ul>
        </div>
        <?php
    }
}

function seo_analyzer_response_heading() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];

    if(get_option('seo_analyzer_field_sapo') == 1 && get_option('seo_analyzer_field_sapo_name')) {
        $sapo = stripslashes($_POST['sapo']);
    }
    ?>
    <div class="sa-response-wrapper sa-heading-wrapper">
        <h3>Heading</h3>
        <ul>
            <?php
            if(get_option('seo_analyzer_field_sapo') == 1 && get_option('seo_analyzer_field_sapo_name')) {
                seo_analyzer_is_sapo($sapo, 'Đã có thẻ H2 trong trang');
            } else {
                seo_analyzer_is_tags('h2', $content, 'Đã có thẻ H2 trong trang');
            }

            seo_analyzer_count_tags('h3', $content, 2, 'Có ít nhất 2 thẻ H3 trong trang');
            seo_analyzer_keyword_tags('h3', $content, $keyword, 2, 'Có ít nhất 2 thẻ H3 chứa từ khóa chính');
            ?>
        </ul>
    </div>
    <?php
}

function seo_analyzer_response_image() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];
    ?>
    <div class="sa-response-wrapper sa-image-wrapper">
        <h3>Image</h3>
        <ul>
            <?php
            seo_analyzer_count_tags('img', $content, 3, 'Có ít nhất 3 hình ảnh trong bài viết');
            seo_analyzer_attr_tags('img', $content, 'alt', 'Có viết nội dung ALT cho tất cả hình ảnh');
            seo_analyzer_keyword_attr_tags('img', $content, 'alt', $keyword, 'Có từ khóa chính trong nội dung ALT của hình ảnh');
            ?>
        </ul>
    </div>
    <?php
}

function seo_analyzer_response_content() {
    $content = stripslashes($_POST['content']);
    $keyword = $_POST['keyword'];
    $subkeyword = $_POST['subkeyword'];

    if(get_option('seo_analyzer_field_sapo') == 1 && get_option('seo_analyzer_field_sapo_name')) {
        $sapo = stripslashes($_POST['sapo']);
    }
    ?>
    <div class="sa-response-wrapper sa-content-wrapper">
        <h3>Content / <?php echo seo_analyzer_str_length($content) ?> từ</h3>
        <ul>
            <?php
            seo_analyzer_length_str($content, 'Nội dung đạt độ dài tối thiểu 1200 từ', 1200, '', 1);
            if(get_option('seo_analyzer_field_sapo') == 1 && get_option('seo_analyzer_field_sapo_name')) {
                seo_analyzer_keyword_first_content($sapo, $keyword, 'Từ khóa chính xuất hiện chính xác ở đoạn văn bản đầu tiên của nội dung');
            } else {
                seo_analyzer_keyword_first_content($content, $keyword, 'Từ khóa chính xuất hiện chính xác ở đoạn văn bản đầu tiên của nội dung');
            }
            seo_analyzer_keyword_content($content, $keyword, 2, '', 'Từ khóa chính đạt đủ mật độ tối thiểu 2% của nội dung');
            seo_analyzer_keyword_content($content, $keyword, '', 3, 'Từ khóa chính không vượt quá 3% nội dung');
            seo_analyzer_keyword_content($content, $subkeyword, 1, '', 'Từ khóa phụ xuất hiện tối thiểu 1% bên trong nội dung');
            ?>
        </ul>
    </div>
    <?php
}

function seo_analyzer_response_tag() {
    $tags = $_POST['tags'];
    $keyword = $_POST['keyword'];

    $terms_tag = array();
    if(get_option('seo_analyzer_editor_used') == 0):
        $terms = get_terms(
            array(
                'taxonomy' => 'post_tag',
                'hide_empty' => false,
                'include' => $tags
            )
        );

        foreach ($terms as $term):
            array_push($terms_tag, mb_strtolower(trim($term->name)));
        endforeach;
    else:
        if($tags) {
            $terms = explode(',', $tags);

            foreach ($terms as $term):
                array_push($terms_tag, mb_strtolower(trim($term)));
            endforeach;
        }
    endif;
    ?>
    <div class="sa-response-wrapper sa-tags-wrapper">
        <h3>Tags</h3>
        <ul>
            <?php seo_analyzer_keyword_in_tags($terms_tag, $keyword, 'Tags đã có từ khóa chính'); ?>
        </ul>
    </div>
    <?php
}

add_action('seo_analyzer_frontend', 'seo_analyzer_response_title', 5);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_description', 10);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_sapo', 10);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_heading', 15);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_image', 20);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_content', 25);
add_action('seo_analyzer_frontend', 'seo_analyzer_response_tag', 30);

function seo_analyzer_post_types() {
    $post_types = array(
        'post' => __('Posts'),
        'page' => __('Pages')
    );

    return $post_types;
}